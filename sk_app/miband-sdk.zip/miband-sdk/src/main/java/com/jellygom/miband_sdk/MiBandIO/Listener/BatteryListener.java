package com.jellygom.miband_sdk.MiBandIO.Listener;

/**
 * Created by mac on 2017. 5. 28..
 */

public interface BatteryListener {
    void onNotify(int battery);
}
