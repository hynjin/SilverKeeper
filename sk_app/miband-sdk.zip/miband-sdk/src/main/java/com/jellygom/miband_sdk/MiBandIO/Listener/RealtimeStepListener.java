package com.jellygom.miband_sdk.MiBandIO.Listener;

public interface RealtimeStepListener {
  void onNotify(int steps);
}
