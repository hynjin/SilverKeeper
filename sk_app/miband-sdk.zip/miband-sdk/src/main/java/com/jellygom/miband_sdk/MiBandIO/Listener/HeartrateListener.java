package com.jellygom.miband_sdk.MiBandIO.Listener;

public interface HeartrateListener {
  void onNotify(int heartRate);
}
