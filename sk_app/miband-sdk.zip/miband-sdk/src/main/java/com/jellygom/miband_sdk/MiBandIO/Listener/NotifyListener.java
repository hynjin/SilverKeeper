package com.jellygom.miband_sdk.MiBandIO.Listener;

public interface NotifyListener {
  void onNotify(byte[] data);
}
